import 'package:flutter/material.dart';
void main() {
  runApp(MyApp());}
class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) { //Setiap widget di Flutter dibuat dari metode build, dan setiap metode build menggunakan BuildContext sebagai argumen
    return MaterialApp( //Widget build digunakan untuk membuat halaman pada aplikasi dengan MaterialApp untuk style UI nya
      debugShowCheckedModeBanner: false ,
      title: 'Mobile A Kel E',
      home: Scaffold( // Scaffold merupakan code untuk membuat detail / konten rancangan UI nya.
        appBar: AppBar( //bagian dari aplikasi mobile yang digunakan untuk menampilkan beberapa navigasi dari aplikasi
          title: Text('12. Konsumsi dan Produksi yang Bertanggung Jawab'),
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center, // letak konten
            children: <Widget>[
              Text( //isi teks
                  'Luthfia Dewana Saputri : 182410103025' '\n'
                  'Mohammad Marsheil Audrey Rasyidi : 182410103039' '\n'
                  'Utut Ardiansah : 182410103057'
              ),
            ],
          ),
        ),
      ),
    );
  }
}